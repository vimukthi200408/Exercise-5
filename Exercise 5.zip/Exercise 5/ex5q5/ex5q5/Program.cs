﻿namespace ex5q5
{
    class Program
    {
        static void Main(string[] ags)
        {


				System.Random random = new System.Random();

				int randnum = random.Next(100), guess;

				Console.WriteLine("Your have to guess the number correctly");
            for (int i = 7; i > 0; i--)
            {
                Console.Write("Your have " + i + " chances : ");
                guess = Convert.ToInt32(Console.ReadLine());
                if (guess > randnum)
                {
                    Console.WriteLine("Too high, try again");
                }
                else if (guess < randnum)
                {
                    Console.WriteLine("Too low, try again");
                }
                else
                {
                    Console.WriteLine("Congratulations you have guessed correctly");
                    System.Environment.Exit(1);
                    break;
                }

            }
            Console.WriteLine("YOU LOST");
            Console.WriteLine("The number was : "+randnum);




        }


	


    }
}