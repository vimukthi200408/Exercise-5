﻿namespace ex5q12
{
    class Program
    {
        static void Main(string[] args)
        {

                int number;
                int max = -232234;
                int min = 100000;

                string choice;

                do
                {
                    Console.Write("Enter the number ");
                    number = Convert.ToInt32(Console.ReadLine());

                    if (number > max)
                    {
                        max = number;
                    }
                if (number < min)
                    {
                        min = number;
                    }

                    Console.Write("Keep adding numbers y/n? ");
                    choice = Console.ReadLine();

                } while (choice == "y");

                    Console.WriteLine("Largest number entered : " + max);
                    Console.WriteLine("Smallest number entered : " + min);
        }
    }

}


