﻿namespace ex5q2
{
    class Program
    {
        static void Main(string[] args)
        {
            double temp, final;

            Console.WriteLine("To convert to Celsius");
            Console.Write("Enter the temperature in Fahrenheit : ");
            temp = Convert.ToDouble(Console.ReadLine());

            final = Convertion(temp);

            Console.WriteLine("");
            Console.Write("The temperature in Celsius is : "+ final);




        }

        static double Convertion(double temp)
        {
            double final;
            final = (temp - 32) / 1.8;


            return final;
        }
    }
}
