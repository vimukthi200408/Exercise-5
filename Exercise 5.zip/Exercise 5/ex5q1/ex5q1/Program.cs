﻿namespace ex5q1
{
    class Program
    {
        static void Main(string[] args)
        {
            double num1, num2, ans = 1; 

            Console.Write("Enter the first number : ");
            num1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the second number : ");
            num2 = Convert.ToDouble(Console.ReadLine());

            for (int i =0; i<num2;i++)
            {
                ans = ans * num1;
            }
            Console.WriteLine(" ");
            Console.WriteLine("value of one number raised to the power of another is : "+ans);



        }
    }
}