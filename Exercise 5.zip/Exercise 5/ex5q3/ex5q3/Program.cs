﻿namespace ex5q3
{
    class Program
    {
        static void Main(string[] ags)
        {
            int[] array = new int[] { 1,4,3,2,4,56,3,2,5,3,5 };

             int[] newarray= reverse(array);
            
            Console.Write("The reversed array is : ");
            for (int i = 0; i < newarray.Length; i++)
            {
                Console.Write(newarray[i] +", ");
            }

            
        }

        static int[] reverse(int[] array)
        {
            int length = array.Length;
            int[] newarray = new int[length];
            length = length - 1;

            for (int i = 0; i < array.Length; i++)
            {
                newarray[i] = array[length];
                length--;

            }

            return newarray;
        }

       
    }
}